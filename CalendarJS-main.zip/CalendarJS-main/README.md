# CalendarJS
Welcome and thank you for visiting my project.
This simple, easy to use, responsive app will help you to plan your events
This web app was created by Evgeniy Toropitsyn (EvTorGen)

In this free to use app you can:
Create new events (press button Create new event)
The current time and date are displayed for your convenience 

Sort your events by 
importance
date of creation
date of event

See basic information about your event:
title
date and time of event
the remaining time 

Modify you events (press button Show more details):
complete and return your event (change the display of the event)
edit your event (the filled out form will open)
completely remove you event
