'use strict'
const viewPage = new ViewPage();
viewPage.saveAndWriteOutListofEvents();
viewPage.showCurrentTime();
viewPage.showAllSavedEvents();
viewPage.sortByImportanceLH();
viewPage.sortByImportanceHL();
viewPage.sortByDateOfEventON();
viewPage.sortByDateOfEventNO();
viewPage.sortByDateOfCreationON();
viewPage.sortByDateOfCreationNO();
viewPage.changeLanguage();
