'use strict'
class EventModel {
    constructor(id, title, date, time, category, description) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
        this.category = category;
        this.description = description;
    }
}

