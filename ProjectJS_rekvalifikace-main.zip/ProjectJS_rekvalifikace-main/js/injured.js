'use strict'
class Pojistenec {
    constructor(celeJmeno, telefon, vek) {
        this.celeJmeno = celeJmeno;
        this.telefon = telefon;
        this.vek = vek;
    }
}
