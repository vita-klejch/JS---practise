'use strict'
const listOfInjured = new ListOfInjured();
listOfInjured.otevritSkrytFormular();
listOfInjured.zapisParametruPojistence();
listOfInjured.seznamPriOtevreni();
listOfInjured.smazatPojistence();